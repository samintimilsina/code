#!/bin/bash
if [ "$1" = "" ] || [ "$2" = "" ]
then
echo "Please give 2 arguements for name and student id respectively."
exit 1
else
echo "Welcome $2, $1 this is a eurocup information application"
echo "Date of execution: "
date "+%d/%m/%y"
echo "Time of execution: "
date "+%H:%M:%S"
rerun=y
while [ "$rerun" = "y" ]
do
cat countries
correct=n
until [ "$correct" = "y" ]
do
echo "Type a country code from above "
read winner
case "$winner" in
ICL|icl|Icl)
echo Iceland 
correct=y
;;
FRA|fra|Fra)
echo France
correct=y
;;
POR|por|Por)
echo Portugal
correct=y
;;
WAL|wal|Wal)
echo Wales
correct=y
;;
GER|ger|Ger)
echo Germany
correct=y
;;
*)
echo "Please make sure that the country code is correct"
;;
esac
done
echo "Some Players of Eurocup:"
cat players
playerLoop=y
while [ "$playerLoop" = "y" ]
do
echo "Type any 3 codes out of these 7 seperating them by space"
read p1 p2 p3
lastWord=$(echo "$p3"|wc -w)
if [ "$lastWord" = '1' ]
then
cp1=$(grep "$p1" players|wc -w)
cp2=$(grep "$p2" players|wc -w)
cp3=$(grep "$p3" players|wc -w)
if [ "$cp1" = '2' ] && [ "$cp2" = '2' ] && [ "$cp3" = '2' ]
then  
playerLoop=n
else
echo "Please enter the correct input from the menu and make sure the case are correct"
playerLoop=y
fi
else
echo "Please type 3 codes only."
playerLoop=y
fi
done
PS3="Choose a player: "
select PLAYER in "$p1" "$p2" "$p3"
do
if [[ -z "$PLAYER" ]]
then
echo "Please choose the player in the menu"
else
pinfo=$(grep -l "$PLAYER" *.txt)
if [ "$pinfo" = '' ]
then
echo "The information file of this player does not exist."
else
cat "$pinfo"
fi
break
fi
done
echo "Do you want to re-run the program?[y/n]"
read rerun
done
fi

